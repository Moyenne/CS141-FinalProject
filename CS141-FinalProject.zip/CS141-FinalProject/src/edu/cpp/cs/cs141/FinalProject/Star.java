package edu.cpp.cs.cs141.FinalProject;

public class Star extends Item
{
	public Star(int xPos, int yPos)
	{
		super(xPos, yPos, "Invinvibility");
	}
}
