package edu.cpp.cs.cs141.FinalProject;

public class Enemy extends GridObject
{
	private boolean isAlive = true;
	
	public Enemy(int xPos, int yPos)
	{
		super(xPos, yPos);
	}
	
	public boolean isAlive()
	{
		return isAlive;
	}
	
	public void die()
	{
		isAlive = false;
	}
}
