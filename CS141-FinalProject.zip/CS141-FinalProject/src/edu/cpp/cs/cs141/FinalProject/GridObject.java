package edu.cpp.cs.cs141.FinalProject;

public class GridObject
{
	private int xPosition;
	private int yPosition;
	
	public GridObject(int xPos, int yPos)
	{
		xPosition = xPos;
		yPosition = yPos;
	}
	
	public int getXPosition()
	{
		return xPosition;
	}
	
	public int getYPosition()
	{
		return yPosition;
	}
	
	public void changePosition(int newXPos, int newYPos)
	{
		xPosition = newXPos;
		yPosition = newYPos;
	}
}
