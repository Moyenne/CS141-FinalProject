package edu.cpp.cs.cs141.FinalProject;

public class Item extends GridObject
{
	private String itemType;
	
	public Item(int xPos, int yPos, String itemType)
	{
		super(xPos, yPos);
		this.itemType = itemType;
	}
	
	public Item(int xPos, int yPos)
	{
		super(xPos, yPos);
		itemType = "None";
	}
	
	public String getType()
	{
		return itemType;
	}
}
