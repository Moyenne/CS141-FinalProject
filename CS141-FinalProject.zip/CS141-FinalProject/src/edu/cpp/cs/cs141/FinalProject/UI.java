package edu.cpp.cs.cs141.FinalProject;

import java.util.Scanner;

public class UI
{
	private Engine engine;
	private Scanner keyboard;
	
	public UI(Engine engine)
	{
		this.engine = engine;
		keyboard = new Scanner(System.in);
	}
	
	public void startGame()
	{
		
	}
}
