package edu.cpp.cs.cs141.FinalProject;

/**
 * AI controlled ninja-assassins. Moves one space randomly. Kills the Player if adjacent at the start of Enemy turn.
 */
public class Enemy extends GridObject
{
	/**
	 * Is the Enemy alive?
	 */
	private boolean isAlive = true;
	
	/**
	 * Constructor for Enemy. Takes location on Grid as arguments.
	 */
	public Enemy(int col, int row)
	{
		super(col, row);
	}
	
	/**
	 * Returns whether or not the Enemy is alive.
	 */
	public boolean isAlive()
	{
		return isAlive;
	}
	
	/**
	 * Kills the Enemy upon being shot by the player.
	 */
	public void die()
	{
		isAlive = false;
	}
}
