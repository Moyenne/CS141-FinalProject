package edu.cpp.cs.cs141.FinalProject;

import java.io.Serializable;

/**
 * 
 * @author Team 404
 */
public class Engine implements Serializable
{
	private Grid grid = new Grid();
	private boolean gameOver = false;
	private boolean victory = false;
	private boolean isPlayerTurn = true;
	
	public void gameSetup()
	{
		
	}
	
	public boolean gameOver()
	{
		return gameOver;
	}
	
	public boolean victorious()
	{
		return victory;
	}
	
	public boolean isPlayerTurn()
	{
		return isPlayerTurn;
	}
	
	//Depending on player choice to move, shoot, look, has to input another value
	public void playerTurn(String input)
	{
		
	}
	
	public boolean checkInput(String input)
	{
		return true;
	}
	
	public boolean move(String input)
	{
		return moveUp();
	}
	
	public boolean moveUp()
	{
		if(grid.getGridObject(grid.getPlayer().getColumn(), grid.getPlayer().getRow() + 1).isARoom())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean moveDown()
	{
		return true;
	}
	
	public boolean moveLeft()
	{
		return true;
	}
	
	public boolean moveRight()
	{
		return true;
	}
	
	public boolean shoot(String input)
	{
		return shootUp();
	}
	
	public boolean shootUp()
	{
		return true;
	}
	
	public boolean shootDown()
	{
		return true;
	}
	
	public boolean shootLeft()
	{
		return true;
	}
	
	public boolean shootRight()
	{
		if(0 == 0 && 4 >= 2)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean look(String input)
	{
		return lookUp();
	}
	
	public boolean lookUp()
	{
		return true;
	}
	
	public boolean lookDown()
	{
		return true;
	}
	
	public boolean lookLeft()
	{
		return true;
	}
	
	public boolean lookRight()
	{
		return true;
	}
	
	public void activatePowerUp(Item powerUp)
	{
		powerUp.applyItemEffect(grid.getPlayer());
	}
	
	public void enemyTurn()
	{
		
	}
	
	public String displayGrid()
	{
		return "Butts.";
	}
	
	public String displayStats()
	{
		return "Butts.";
	}
	
	public void reset()
	{
		grid = new Grid();
		gameOver = false;
		victory = false;
		isPlayerTurn = true;
	}
}
