package edu.cpp.cs.cs141.FinalProject;

import java.io.Serializable;
import java.util.Random;

public class Grid implements Serializable
{
	private GridObject[][] grid = new GridObject[9][9];
	private Player player;
	
	public Grid()
	{
		generalGridSetup();
	}
	
	private void generalGridSetup()
	{
		player = new Player(0, 8);
		addGridObject(player, 0, 8);
		roomSetup();
		enemySetup();
		itemSetup();
	}

	private void roomSetup()
	{
		Room[] temp = new Room[9];
		Room room1 = new Room(1, 1, 1); temp[0] = room1;
		Room room2 = new Room(2, 4, 1); temp[1] = room2;
		Room room3 = new Room(3, 7, 1); temp[2] = room3;
		Room room4 = new Room(4, 1, 4); temp[3] = room4;
		Room room5 = new Room(5, 4, 4); temp[4] = room5;
		Room room6 = new Room(6, 7, 4); temp[5] = room6;
		Room room7 = new Room(7, 1, 7); temp[6] = room7;
		Room room8 = new Room(8, 4, 7); temp[7] = room8;
		Room room9 = new Room(9, 7, 7); temp[8] = room9;
		int x = new Random().nextInt(9);
		temp[x].placeBriefcase();
		addGridObject(temp[0], 1, 1);
		addGridObject(temp[1], 4, 1);
		addGridObject(temp[2], 7, 1);
		addGridObject(temp[3], 1, 4);
		addGridObject(temp[4], 4, 4);
		addGridObject(temp[5], 7, 4);
		addGridObject(temp[6], 1, 7);
		addGridObject(temp[7], 4, 7);
		addGridObject(temp[8], 7, 7);
	}
	
	private void enemySetup()
	{
		
	}

	private void itemSetup()
	{
		
	}
	
	public void addGridObject(GridObject gridObject, int col, int row)
	{
		grid[col][row] = gridObject;
	}
	
	public void removeGridObject(int col, int row)
	{
		grid[col][row] = null;
	}
	
	public GridObject getGridObject(int col, int row)
	{
		return grid[col][row];
	}
	
	public void moveGridObject(int currentCol, int currentRow, int newCol, int newRow)
	{
		//if(grid[newXPos][newYPos] == null)
		//{
			grid[newCol][newRow] = grid[currentCol][currentRow];
			grid[newCol][newRow].changePosition(newCol, newRow);
			grid[currentCol][currentRow] = null;
		//}
	}
	
	public Player getPlayer()
	{
		return player;
	}
	
	public String drawGrid()
	{
		return "[x][x][x][x][P][x][x][x][x]";
	}
}
