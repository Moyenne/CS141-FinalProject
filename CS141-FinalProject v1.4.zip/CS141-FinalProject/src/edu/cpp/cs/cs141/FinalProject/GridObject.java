package edu.cpp.cs.cs141.FinalProject;

import java.io.Serializable;

/**
 * This class represents all objects that are going to be placed on the grid throughout
 * the game. The main purpose of this class is to save shared aspects between the various
 * different objects, such as a position on the grid.
 * @author Team 404
 */
public class GridObject implements Serializable
{
	/**
	 * An int value that tells a GridObject's horizontal location on the grid. Another way
	 * of looking at it: the x value on a Cartesian plane.
	 */
	private int column;
	
	/**
	 * An int value that tells a GridObject's vertical location on the grid. Another way
	 * of looking at it: the y value on a Cartesian plane.
	 */
	private int row;
	
	/**
	 * An enumerated type variable that is of specific values: PLAYER, ENEMY, ROOM, ITEM.
	 * This is used for later grid scanning/object representation.
	 */
	public static enum ObjectType{DEFAULT, PLAYER, ENEMY, ROOM, ITEM};
	
	/**
	 * An ObjectType value representing the specific type of GridObject that a GridObject is,
	 * which... is... huh. That's kinda weird. Well, let's make it DEFAULT. This is used for
	 * later grid scanning in subclasses.
	 */
	public ObjectType secret = ObjectType.DEFAULT;
	
	/**
	 * The main constructor for the class, which accepts two int values for parameters.
	 * This decides the initial starting location for a GridObject.
	 * @param col is the to-be-stored column value of the GridObject.
	 * @param row is the to-be-stored row value of the GridObject.
	 */
	public GridObject(int col, int row)
	{
		column = col;
		this.row = row;
	}
	
	/**
	 * A simple method that returns the int value stored in the column variable.
	 */
	public int getColumn()
	{
		return column;
	}
	
	/**
	 * A simple method that returns the int value stored in the row variable.
	 */
	public int getRow()
	{
		return row;
	}
	
	/**
	 * A method that accepts two int values as parameters, and sets them to the new column and row values.
	 * This method is called after a GridObject has been moved on the grid, so a GridObject's coordinates
	 * actually match its position.
	 * @param newCol is the new column value to be stored.
	 * @param newRow is the new row value to be stored.
	 */
	public void changePosition(int newCol, int newRow)
	{
		column = newCol;
		row = newRow;
	}
	
	/**
	 * A simple method that returns false always, confirming this is, in fact, not a room. This is
	 * used for grid scans later on in the Engine and Grid classes.
	 */
	public boolean isARoom()
	{
		return false;
	}
	
	/**
	 * A simple method that returns false always, confirming this is, in fact, not an item. This is
	 * used for grid scans later on in the Engine and Grid classes.
	 */
	public boolean isAnItem()
	{
		return false;
	}
	
	/**
	 * A simple method that returns the ObjectType value stored in the secret variable. 
	 */
	public ObjectType getObjectType()
	{
		return secret;
	}
}
