package edu.cpp.cs.cs141.FinalProject;

public class Enemy extends GridObject
{
	private boolean isAlive = true;
	
	public Enemy(int col, int row)
	{
		super(col, row);
	}
	
	public boolean isAlive()
	{
		return isAlive;
	}
	
	public void die()
	{
		isAlive = false;
	}
}
