package edu.cpp.cs.cs141.FinalProject;

public class GridObject
{
	private int column;
	private int row;
	
	public GridObject(int col, int row)
	{
		column = col;
		this.row = row;
	}
	
	public int getColumn()
	{
		return column;
	}
	
	public int getRow()
	{
		return row;
	}
	
	public void changePosition(int newCol, int newRow)
	{
		column = newCol;
		row = newRow;
	}
	
	public boolean isARoom()
	{
		return false;
	}
	
	public boolean isAnItem()
	{
		return false;
	}
}
