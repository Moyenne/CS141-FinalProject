package edu.cpp.cs.cs141.FinalProject;

public class Room extends GridObject
{
	private int number;
	private boolean containsBriefcase = false;
	
	public Room(int number, int col, int row)
	{
		super(col, row);
		this.number = number;
	}
	
	public int getRoomNumber()
	{
		return number;
	}
	
	public boolean containsBriefcase()
	{
		return containsBriefcase;
	}
	
	public void placeBriefcase()
	{
		containsBriefcase = true;
	}
	
	public boolean isARoom()
	{
		return true;
	}
}
