package edu.cpp.cs.cs141.FinalProject;

public class Bullet extends Item
{
	public Bullet(int col, int row)
	{
		super("Bullet", col, row);
	}
}
