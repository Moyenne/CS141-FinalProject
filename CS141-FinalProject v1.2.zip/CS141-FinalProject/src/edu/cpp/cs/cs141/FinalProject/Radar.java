package edu.cpp.cs.cs141.FinalProject;

public class Radar extends Item
{
	public Radar(int col, int row)
	{
		super("Radar", col, row);
	}
}
