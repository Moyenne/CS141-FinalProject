package edu.cpp.cs.cs141.FinalProject;

public class Player extends GridObject
{
	private int lifeCount = 3;
	private boolean isInvincible = false;
	private boolean hasBullet = true;
	
	public Player(int col, int row)
	{
		super(col, row);
	}
	
	public int getLifeCount()
	{
		return lifeCount;
	}
	
	public void reduceLifeCount()
	{
		lifeCount--;
	}
	
	public boolean isInvincible()
	{
		return isInvincible;
	}
	
	public void switchInvincibility()
	{
		if(isInvincible)
		{
			isInvincible = false;
		}
		else
		{
			isInvincible = true;
		}
	}
	
	public boolean hasBullet()
	{
		return hasBullet;
	}
	
	public void gainBullet()
	{
		if(!hasBullet)
		{
			hasBullet = true;
		}
	}
	
	public void shoot()
	{
		hasBullet = false;
	}
}
