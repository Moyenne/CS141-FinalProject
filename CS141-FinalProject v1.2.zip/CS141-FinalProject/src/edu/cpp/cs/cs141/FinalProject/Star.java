package edu.cpp.cs.cs141.FinalProject;

public class Star extends Item
{
	public Star(int col, int row)
	{
		super("Invinvibility", col, row);
	}
}
