package edu.cpp.cs.cs141.FinalProject;

public class Item extends GridObject
{
	private String itemType;
	
	public Item(String itemType, int col, int row)
	{
		super(col, row);
		this.itemType = itemType;
	}
	
	public Item(int xPos, int yPos)
	{
		super(xPos, yPos);
		itemType = "None";
	}
	
	public String getType()
	{
		return itemType;
	}
	
	public boolean isAnItem()
	{
		return true;
	}
}
