package streams;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class StreamingFilesLegally
{	
	public static void main(String[] args)
	{
		int x = 42;
		double d = 42.0;
		boolean b = true;
		writeIntoFile(x,d,b);
		readFromFile();
	}
	
	private static void readFromFile()
	{
		try
		{
			FileInputStream fis = new FileInputStream("theFile.file");
			DataInputStream dis = new DataInputStream(fis);
			double d = dis.readDouble();
			boolean b = dis.readBoolean();
			int x = dis.readInt();
			System.out.println("Double: " + d + " Boolean: " + b + " Int: " + x);
			fis.close();
		}
		catch(IOException e)
		{
			System.out.println("Oops... you seem to have met a terrible fate.");
		}
	}

	private static void writeIntoFile(int x, double d, boolean b)
	{
		try
		{
			FileOutputStream fos = new FileOutputStream("theFile.file");
			DataOutputStream dos = new DataOutputStream(fos);
			dos.writeInt(x);
			dos.writeDouble(d);
			dos.writeBoolean(b);
			fos.close();
		}
		catch(IOException e)
		{
			System.out.println("Oops... you seem to have met a terrible fate.");
		}
	}
}
