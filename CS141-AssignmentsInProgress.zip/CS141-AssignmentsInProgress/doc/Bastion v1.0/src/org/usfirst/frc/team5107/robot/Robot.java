package org.usfirst.frc.team5107.robot;

import edu.wpi.cscore.UsbCamera;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.SpeedController;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.VictorSP;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;


/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
// This is the good bot.
public class Robot extends IterativeRobot {
	RobotDrive myRobot = new RobotDrive(0, 1, 2, 3);
	Joystick leftStick = new Joystick(1);
	Joystick rightStick = new Joystick(0);
	private SpeedController winchMotor = new VictorSP(4);
//	private SpeedController launcherMotor = new VictorSP(4);
//	private SpeedController aggroMotor = new VictorSP(6);
	private JoystickButton button1 = new JoystickButton(leftStick, 1);
	private JoystickButton button2 = new JoystickButton(leftStick, 2);
	private JoystickButton button3 = new JoystickButton(leftStick, 3);
	private JoystickButton button4 = new JoystickButton(leftStick, 4);
	private JoystickButton button5 = new JoystickButton(leftStick, 5);
	private final double kUpdatePeriod = 0.005;
	private final int x = 1;
	Timer timer = new Timer();

	/**
	 * This function is run when the robot is first started up and should be
	 * used for any initialization code.
	 */
	@Override
	public void robotInit() {
		CameraServer.getInstance().startAutomaticCapture();
//		camera.setResoultion( , );
	}

	/**
	 * This function is run once each time the robot enters autonomous mode
	 */
	@Override
	public void autonomousInit() {
		timer.reset();
		timer.start();
	}

	/**
	 * This function is called periodically during autonomous
	 */
	@Override
	public void autonomousPeriodic() {
		if (timer.get() < 15.0) { // GOOD TO GO! JUST CHECK LATER TO MAKE SURE
			if (x == 0) {
				while (timer.get() < 6) {
					myRobot.drive(0.25, 0.0);
				}
				while (timer.get() >= 6) {
					myRobot.drive(0.0, 0.0); // Turn left
																	// 90
																	// degrees
				}
			} else if (x == 1) { // THIS IS FOR STARTING ON THE LEFT SIDE Needs
									// a few tests
				while(timer.get() < 10)
				{
					myRobot.setLeftRightMotorOutputs(-0.3, -0.25);											// degrees
				}
			} else if (x == 2) { // THIS IS FOR STARTING ON THE RIGHT SIDE Needs
									// a few tests
				while(timer.get() < 5)
				{
					myRobot.drive(-0.25, 0.0);
				}
				while(timer.get() >= 5 && timer.get() < 7)
				{
					myRobot.drive(0.0, 0.0);
				}
				while(timer.get() >= 7 && timer.get() < 15)
				{
					myRobot.drive(-0.3, 0.0);
				}
			} else {
				System.out.println("You funked up somewhere, bud. Fix your shite.");
			}
		} else {
			myRobot.drive(0.0, 0.0);
			teleopInit();
		}
	}
	/**
	 * if (x == 0) {
				while (timer.get() < 1) {
					myRobot.drive(0.6, 0.0);
				}
				while (timer.get() >= 1 && timer.get() < 2) {
					myRobot.drive(0.3, 0);
				}
				while (timer.get() >= 2 && timer.get() < 2.5) {
					myRobot.drive(0, 0);
				}
				while (timer.get() >= 2.5 && timer.get() < 4) {
					myRobot.drive(-0.4, 0);
				}
				while (timer.get() >= 4 && timer.get() < 5) {
					myRobot.setLeftRightMotorOutputs(-0.26, 0.26); // Turn left
																	// 90
																	// degrees
				}
				while (timer.get() >= 5 && timer.get() < 7) {
					myRobot.drive(-0.4, 0);
				}
				while (timer.get() >= 7 && timer.get() < 8) {
					myRobot.setLeftRightMotorOutputs(-0.25, 0.25); // Turn right
																	// 90
																	// degrees
				}
				while (timer.get() >= 8 && timer.get() < 15) {
					myRobot.drive(-0.25, 0);
				}
			} else if (x == 1) { // THIS IS FOR STARTING ON THE LEFT SIDE Needs
									// a few tests
				while(timer.get() < 2)
				{
					myRobot.drive(.4, 0.0);
				}
				while(timer.get() >= 2 && timer.get() < 2.75)
				{
					myRobot.setLeftRightMotorOutputs(0.2, -0.2);
				}
				while(timer.get() >= 7 && timer.get() < 15)
				{
					myRobot.drive(-0.2, 0.0);
				}
			} else if (x == 2) { // THIS IS FOR STARTING ON THE RIGHT SIDE Needs
									// a few tests
				while(timer.get() < 5)
				{
					myRobot.drive(-0.25, 0.0);
				}
				while(timer.get() >= 5 && timer.get() < 7)
				{
					myRobot.drive(0.0, 0.0);
				}
				while(timer.get() >= 7 && timer.get() < 15)
				{
					myRobot.drive(-0.2, 0.0);
				}
			} else {
				System.out.println("You funked up somewhere, bud. Fix your shite.");
			}
	 */
	/**
	 * This function is called once each time the robot enters tele-operated
	 * mode
	 */
	@Override
	public void teleopInit() {
	}

	/**
	 * This function is called periodically during operator control
	 */
	@Override
	public void teleopPeriodic() {
		myRobot.tankDrive(leftStick, rightStick);

		if (button1.get()) {
			winchMotor.set(-1.0);
		} else if (button4.get()) {
			winchMotor.set(1.0);
		} else {
			winchMotor.set(0.0);
		}
//		if (button2.get()) {
//			launcherMotor.set(1.0);
//		} else {
//			launcherMotor.set(0.0);
//		}
//		if (button3.get()) {
//			aggroMotor.set(0.4);
//		} else if (button5.get()) {
//			aggroMotor.set(-0.4);
//		} else {
//			aggroMotor.set(0.0);
//		}
		Timer.delay(kUpdatePeriod); // wait 5ms to the next update
	}

	/**
	 * This function is called periodically during test mode
	 */
	@Override
	public void testPeriodic() {
		LiveWindow.run();
	}
}

// Hayden was here
// Hayden was here
// Hayden was here
// Hayden was here