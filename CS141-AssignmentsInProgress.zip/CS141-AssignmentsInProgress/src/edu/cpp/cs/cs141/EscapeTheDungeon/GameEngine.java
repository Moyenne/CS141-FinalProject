package edu.cpp.cs.cs141.EscapeTheDungeon;

import java.util.Random;

/**
 * This class serves to control all of the game's major functions and rule sets, determining
 * player movement and action, various game states, and the creation/destruction of enemies.
 * It's a bit complicated.
 * @author Moyenne
 */
public class GameEngine
{
	/**
	 * player is an initialized ActiveAgent object, which 'spawns' the player into the game,
	 * with a gun to use, and the ability to move/act. This process begins at the start of the
	 * game in the UserInterface class.
	 */
	private ActiveAgent player;
	
	/**
	 * enemy is an initialized ActiveAgent object, which 'spawns' an enemy into the game, with
	 * a random gun to use, and the ability to fight the player. Enemies are only created when
	 * combat begins, and are reset after combat.
	 */
	private ActiveAgent enemy;
	
	/**
	 * currentSpace is an int variable, set to a default value of 0 when GameEngine is initialized.
	 * It represents how far along the player has moved to escape the dungeon, and is checked by the
	 * checkWinCondition method.
	 */
	private int currentSpace = 0;
	
	/**
	 * gameSetUp is a boolean variable, set to a default value of false when GameEngine is initialized.
	 * It represents whether or not the player Agent has been properly created, and is checked in the
	 * UserInterface to determine whether or not to progress with game functions.
	 */
	private boolean gameSetUp = false;
	
	/**
	 * gameFinished is a boolean variable, set to a default value of false when GameEngine is initialized.
	 * It represents whether or not the game has reached some form of end, but does not specify victory or
	 * defeat. It is constantly checked in UserInterface to keep the game running.
	 */
	private boolean gameFinished = false;
	
	/**
	 * victory is a boolean variable, set to a default value of false when GameEngine is initialized.
	 * It represents whether or not the player has beaten the game, and is checked in UserInterface to
	 * determine if the game should congratulate the player's success, or denounce their failure.
	 */
	private boolean victory = false;
	
	/**
	 * battleTurn is a boolean variable, set to a default value of false when GameEngine is initialized.
	 * It represents whether or not the game is in its combat phase, and is checked constantly by the
	 * UserInterface to determine what choices to give the player.
	 */
	private boolean battleTurn = false;
	
	/**
	 * playerTurn is a boolean variable, set to a default value of false when GameEngine is initialized.
	 * It represents whether or not it is currently the player's turn, determining if the player is
	 * allowed to act or not.
	 */
	private boolean playerTurn = false;
	
	/**
	 * random is an initialized Random object, which is used to calculate the chance of an enemy
	 *spawning when moving to the next space, as well as calculate the chance of escaping combat
	 *and what type of item is dropped after succeeding in combat. It works off of constant values
	 *in the program.
	 */
	private Random random = new Random();
	
	/**
	 * A simple method that returns the current value being stored by gameSetUp.
	 */
	public boolean getSetUp()
	{
		return gameSetUp;
	}
	
	/**
	 * A simple method that returns the current value being stored by gameFinished.
	 */
	public boolean gameOver()
	{
		return gameFinished;
	}
	
	/**
	 * A simple method that returns the current value being stored by victory.
	 */
	public boolean victorious()
	{
		return victory;
	}
	
	/**
	 * A simple method that returns the current value being stored by battleTurn.
	 */
	public boolean inCombat()
	{
		return battleTurn;
	}
	
	/**
	 * A simple method that returns the current value being stored by playerTurn.
	 */
	public boolean isPlayerTurn()
	{
		return playerTurn;
	}
	
	/**
	 * A simple method that returns a boolean value respective to whether or not the current enemy has
	 * more than 0 hit points, ending or continuing combat depending on the result.
	 */
	private boolean checkCombatWinCondition()
	{
		if(enemy.getHitPoints() <= 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * A simple method that returns a boolean value respective to whether or not the player has taken 10
	 * steps to escape the dungeon, beating the game in the process.
	 */
	private boolean checkWinCondition()
	{
		if(currentSpace == 10)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * A simple method that returns a boolean value respective to whether or not the player has been reduced
	 * to 0 or less hit points, losing the game in the process.
	 */
	private boolean checkLoseCondition()
	{
		if(player.getHitPoints() <= 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * A method that accepts a parameter of type of String, comparing it to the acceptable values of gunType
	 * from the Gun class. If an acceptable value is chosen, then a new ActiveAgent is initialized with that
	 * gun type, gameSetUp is set to true, and getSetUp is called, returning the value.
	 */
	public boolean setUp(String gunType)
	{
		if(gunType.equals("PISTOL") || gunType.equals("RIFLE") || gunType.equals("SHOTGUN"))
		{
			player = new ActiveAgent(new Gun(gunType));
			gameSetUp = true;
			return getSetUp();
		}
		else
		{
			gameSetUp = false;
			return getSetUp();
		}
	}
	
	/**
	 * A method that accepts a parameter of type String, checks if the player has beaten the game with this
	 * move, then determines if the player encounters an enemy, beginning combat if that is the case. A boolean
	 * is returned depending on if an acceptable String value is input (with 'take one step' being the only
	 * acceptable value).
	 */
	public boolean takeMovementTurn(String takeOneStep)
	{
		if(checkInput(takeOneStep))
		{
			currentSpace = 10;
			victory = checkWinCondition();
			gameFinished = victory;
			if (!gameFinished && randomEncounter())
			{
				startCombat();
				System.out.println("You have encountered a random enemy! Press enter to continue.");
			}
			else
			{
				System.out.println("Move successful. Press enter to continue.");
			}
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * A method that accepts a parameter of type String, checks if the player is attacking or attempting to run
	 * away, then determines if the player is successful with either option. If it is the enemy's turn, then they
	 * will always attempt to attack the player. Combat is ended if either the player or enemy dies. A boolean
	 * is returned depending on if an acceptable String value is input (with 'shoot' and 'try to escape' being the only
	 * acceptable values).
	 */
	public boolean takeCombatTurn(String actionChoice)
	{
		if(playerTurn)
		{
			boolean goodInput = checkInput(actionChoice);
			if(goodInput)
			{
				if(actionChoice.toLowerCase().equals("shoot"))
				{
					shoot();
					if (checkCombatWinCondition())
					{
						battleTurn = false;
						findItemDrop();
					}
					else
					{
						playerTurn = false;
					}
				}
				else if(actionChoice.toLowerCase().equals("try to escape"))
				{
					if (tryToEscape())
					{
						battleTurn = false;
						currentSpace--;
					}
					else
					{
						playerTurn = false;
					}
				}
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			shoot();
			if(checkLoseCondition())
			{
				battleTurn = false;
				playerTurn = false;
				gameFinished = true;
			}
			else
			{
				playerTurn = true;
			}
			return true;
		}
	}
	
	/**
	 * A method that takes a parameter of type String, and, depending on whether or not the player is in
	 * combat or not, compares the String to make sure it is an acceptable value.
	 */
	private boolean checkInput(String inputString)
	{
		if(battleTurn == false)
		{
			if(inputString.toLowerCase().equals("take one step"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			if(inputString.toLowerCase().equals("shoot") || inputString.toLowerCase().equals("try to escape"))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	
	/**
	 * A simple method that randomly determines if the player encounters an enemy when they move, returning a
	 * boolean value respective of this.
	 */
	private boolean randomEncounter()
	{
		int encounterChance = random.nextInt(100);
		if(encounterChance < 15)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/**
	 * A simple method that, when called, creates a new ActiveAgent of type ENEMY, assigns the new Agent to the
	 * enemy variable, and sets the battleTurn and playerTurn variables both to true, making the player always
	 * act first in combat.
	 */
	private void startCombat()
	{
		enemy = new ActiveAgent(ActiveAgent.AgentType.ENEMY);
		System.out.println("An enemy with a " + enemy.getGun().getGunType() + " has appeared.");
		battleTurn = true;
		playerTurn = true;
	}
	
	/**
	 * A method that runs all calculations for both players and enemies shooting, calling multiple methods of the
	 * Gun class to calculate the chance of a hit, the damage dealt, and the consideration of ammo.
	 */
	private void shoot()
	{
		if(playerTurn)
		{
			if(player.getGun().getCurrentAmmo() > 0)
			{
				if(player.getGun().attack())
				{
					enemy.reduceHitPoints(player.getGun().getDamage());
					System.out.println("Nice hit, you dealt " + player.getGun().getDamage() + " damage. Press enter to continue.");
				}
				else
				{
					System.out.println("Dang, too bad. You missed. Press enter to continue.");
				}
			}
			else
			{
				System.out.println("You have no ammo! Press enter to continue.");
			}
		}
		else
		{
			if(enemy.getGun().attack2())
			{
				player.reduceHitPoints(enemy.getGun().getDamage());
				System.out.println("Ouch! You took " + enemy.getGun().getDamage() + " damage. Press enter to continue.");
			}
			else
			{
				System.out.println("Whew, thank goodness. The enemy missed. Press enter to continue.");
			}
		}
	}
	
	/**
	 * A method that randomly determines if the player's attempt to escape combat is successful, returning a boolean
	 * value that is representative of such.
	 */
	private boolean tryToEscape()
	{
		int escapeChance = random.nextInt(100);
		if(escapeChance < 10)
		{
			System.out.println("Escape successful! But you go back a space... Press enter to continue.");
			return true;
		}
		else
		{
			System.out.println("Escape failed! Better luck next time. Press enter to continue.");
			return false;
		}
	}
	
	/**
	 * A method that creates and determines the type of an ItemDrop object, then uses its type to decide whether to:
	 * heal the player for 5 hit points, or fully recover the player's ammo.
	 */
	private void findItemDrop()
	{
		ItemDrop item;
		int itemChance = random.nextInt(100);
		if(itemChance < 30)
		{
			item = new ItemDrop(ItemDrop.DropType.HEALTH);
		}
		else
		{
			item = new ItemDrop();
		}
		if(item.getType().equals(ItemDrop.DropType.HEALTH))
		{
			player.recoverHitPoints();
			System.out.println("The enemy dropped a Health Pack. You recover 5 hit points. Press enter to continue.");
		}
		else
		{
			player.getGun().fillAmmo();
			System.out.println("The enemy dropped an Ammo Pack. You recover all of your " + player.getGun().getGunType() + " ammo. Press enter to continue.");
		}
	}
	
	/**
	 * A simple method that returns a String detailing the health, gun type, and current ammo of the player, which is
	 * performed before every move/action.
	 */
	public String displayStats()
	{
		return "Health: " + player.getHitPoints() + "\tGun: " + player.getGun().getGunType() + "\tAmmo: " + player.getGun().getCurrentAmmo() + "\n"
				+ "\t" + (10 - currentSpace) + " spaces remaining before escape.";
	}
	
	/**
	 * A simple method that returns a String detailing the health and gun type of the current enemy being faced.
	 */
	public String displayEnemyStats()
	{
		return "Enemy Health: " + enemy.getHitPoints() + "\tGun: " + enemy.getGun().getGunType();
	}
	
	/**
	 * A simple method that resets all field variables to their default values.
	 */
	public void reset()
	{
		player = null;
		currentSpace = 0;
		gameSetUp = false;
		gameFinished = false;
		victory = false;
		battleTurn = false;
		playerTurn = false;
	}
}
