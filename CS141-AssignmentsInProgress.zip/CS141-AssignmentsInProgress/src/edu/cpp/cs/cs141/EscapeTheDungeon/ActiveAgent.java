package edu.cpp.cs.cs141.EscapeTheDungeon;

import java.util.Random;

/**
 * This class serves to define the various types of Active Agents that are able to be
 * spawned in the game, specifically players and enemies. It also includes hit points
 * for the Agents, as well as which gun they are using. There are methods to access
 * these values, as well as change them dependent on certain scenarios determined by
 * the GameEngine.
 * @author Moyenne
 */
public class ActiveAgent
{
	/**
	 * AgentType is an enumerated type variable, which can be either PLAYER or ENEMY
	 * values.
	 */
	public static enum AgentType{PLAYER, ENEMY};
	
	/**
	 * type is a variable of type AgentType, allowing it to store the two different
	 * values listed above.
	 */
	private AgentType type;
	
	/**
	 * hitPoints is an int variable, with a value dependent on the type of ActiveAgent
	 * initialized, as well as the damage dealt to the Agent.
	 */
	private int hitPoints;
	
	/**
	 * gun is an initialized Gun object, which determines what type of Gun the Agent is
	 * using.
	 */
	private Gun gun;
	
	/**
	 * random is an initialized Random object, which is used to calculate the chance of an enemy
	 *spawning with a particular type of gun. It works off of constant values in the program.
	 */
	private Random random = new Random();
	
	/**
	 * A default version of the constructor, which accepts a parameter of type Gun, which is set
	 * to the value stored by gun. type is set to a default value of PLAYER, and hitPoints is set
	 * to a default value of 20.
	 */
	public ActiveAgent(Gun gun)
	{
		type = AgentType.PLAYER;
		hitPoints = 20;
		this.gun = gun;
	}
	
	/**
	 * An alternative version of the constructor, which accepts a parameter of type AgentType, which
	 * must be ENEMY for this constructor to function. Default values for an enemy agent are then
	 * assigned, with the gun being chosen via the enemyGunSetup method.
	 */
	public ActiveAgent(AgentType agentType)
	{
		if(agentType.equals(AgentType.ENEMY))
		{
			type = agentType;
			hitPoints = 5;
			enemyGunSetup();
		}
		else
		{
			System.out.println("Incorrect agent setup, please try again.");
		}
	}
	
	/**
	 * A method that randomly determines the type of gun used by the agent, only accessible by enemies,
	 * who have their guns determined by a constant percentage.
	 */
	private void enemyGunSetup()
	{
		int gunChance = random.nextInt(100);
		if(gunChance < 50)
		{
			gun = new Gun();
		}
		else if(gunChance >= 50 && gunChance < 85)
		{
			gun = new Gun("RIFLE");
		}
		else
		{
			gun = new Gun("SHOTGUN");
		}
	}
	
	/**
	 * A simple method that returns the current AgentType being stored by type.
	 */
	public AgentType getType()
	{
		return type;
	}
	
	/**
	 * A simple method that returns the Gun object being stored by gun.
	 */
	public Gun getGun()
	{
		return gun;
	}
	
	/**
	 * A simple method that returns the current value being stored by hitPoints.
	 */
	public int getHitPoints()
	{
		return hitPoints;
	}
	
	/**
	 * A method that adds 5 to the current value being stored by hitPoints, although it cannot
	 * exceed 20, as that is the maximum health of a player Agent.
	 */
	public void recoverHitPoints()
	{
		if(hitPoints + 5 < 20)
		{
			hitPoints += 5;
		}
		else if (hitPoints + 5 >= 20)
		{
			hitPoints = 20;
		}
	}
	
	/**
	 * A method that takes an int parameter, and reduces the current value being stored by hitPoints
	 * by that amount. This is used to 'damage' agents, although the death of an agent is determined
	 * by the GameEngine.
	 */
	public void reduceHitPoints(int reduceBy)
	{
		hitPoints -= reduceBy;
	}
}
