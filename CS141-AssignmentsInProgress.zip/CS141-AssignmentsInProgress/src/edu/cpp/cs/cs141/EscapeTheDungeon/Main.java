package edu.cpp.cs.cs141.EscapeTheDungeon;

/**
 * This class serves to start all game functions for the Escape the Dungeon game. It contains
 * the main method, which begins the whole process of initializing and running the game.
 * @author Moyenne
 */
public class Main
{
	/**
	 * A method which creates a new UserInterface object, and starts the game using its
	 * startGame method. This also initializes the GameEngine responsible for all of the
	 * game's rules.
	 */
	public static void main(String[] args)
	{
		UserInterface ui = new UserInterface(new GameEngine());
		ui.startGame();
	}
}
