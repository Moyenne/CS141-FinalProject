package edu.cpp.cs.cs141.EscapeTheDungeon;

import java.util.Random;

/**
 * This class serves to define the various types of Guns usable in the game, as well
 * as certain characteristics for each gun type, such as damage, ammunition, and accuracy.
 * Methods are included to access these variables, as well as 'fire' the weapon, which
 * is used in the GameEngine class.
 * @author Moyenne
 */
public class Gun
{
	/**
	 * GunType is an enumerated type variable, which can be either PISTOL, RIFLE, or SHOTGUN.
	 */
	public static enum GunType{PISTOL, RIFLE, SHOTGUN};
	
	/**
	 * type is a variable of type GunType, allowing it to store the three different values
	 * listed above.
	 */
	private GunType type;
	
	/**
	 * maxAmmo is an int variable, with a value dependent on the type of gun that is initialized.
	 * It represents the maximum amount of ammo that the particular gun type can hold.
	 */
	private int maxAmmo;
	
	/**
	 * currentAmmo is an int variable, with a value dependent on how many times the gun has been fired,
	 * as well as if any ammo drops have been found. It represents how much ammo the gun is currently
	 * holding.
	 */
	private int currentAmmo;
	
	/**
	 * damage is an int variable, with a value dependent on the type of gun that is initialized.
	 * It represents the constant amount of damage that the particular gun type deals per shot.
	 */
	private int damage;
	
	/**
	 * accuracy is an int variable, with a value dependent on the type of gun that is initialized.
	 * It represents the percentage chance that a particular gun type has to land an individual shot.
	 */
	private int accuracy;
	
	/**
	 * random is an initialized Random object, which is used to calculate the chance of a gun landing
	 * a shot when fired. It uses the respective value of accuracy to determine the range of success.
	 */
	private Random random = new Random();
	
	/**
	 * A basic, default constructor that sets type to a default value of PISTOL, as well as calls the
	 * gunSetupPistol method.
	 */
	public Gun()
	{
		type = GunType.PISTOL;
		gunSetupPistol();
	}
	
	/**
	 * Another version of the constructor which accepts a parameter of type String, and compares that
	 * String to the various values accepted by GunType, calling the respective gunSetup method, or
	 * printing out an error message if an acceptable value is not chosen.
	 */
	public Gun(String gunType)
	{
		if(gunType.equals("PISTOL"))
		{
			gunSetupPistol();
		}
		else if(gunType.equals("RIFLE"))
		{
			gunSetupRifle();
		}
		else if(gunType.equals("SHOTGUN"))
		{
			gunSetupShotgun();
		}
		else
		{
			System.out.println("Improper gun type selected.");
		}
	}
	
	/**
	 * A method that sets type, maxAmmo, currentAmmo, damage, and accuracy to the default PISTOL values.
	 */
	private void gunSetupPistol()
	{
		type = GunType.PISTOL;
		maxAmmo = 15;
		currentAmmo = 15;
		damage = 1;
		accuracy = 75;
	}
	
	/**
	 * A method that sets type, maxAmmo, currentAmmo, damage, and accuracy to the default RIFLE values.
	 */
	private void gunSetupRifle()
	{
		type = GunType.RIFLE;
		maxAmmo = 10;
		currentAmmo = 10;
		damage = 2;
		accuracy = 65;
	}
	
	/**
	 * A method that sets type, maxAmmo, currentAmmo, damage, and accuracy to the default SHOTGUN values.
	 */
	private void gunSetupShotgun()
	{
		type = GunType.SHOTGUN;
		maxAmmo = 5;
		currentAmmo = 5;
		damage = 5;
		accuracy = 40;
	}
	
	/**
	 * A simple method that returns the current value being stored by currentAmmo.
	 */
	public int getCurrentAmmo()
	{
		return currentAmmo;
	}
	
	/**
	 * A simple method that sets the value of currentAmmo equal to the value of maxAmmo for the particular
	 * gun type being used.
	 */
	public void fillAmmo()
	{
		currentAmmo = maxAmmo;
	}
	
	/**
	 * A simple method that reduces the current value of currentAmmo by 1, assuming it is greater than 0.
	 */
	public void reduceAmmo()
	{
		if(currentAmmo > 0)
		{
			currentAmmo--;
		}
	}
	
	/**
	 * A simple method that returns the current value being stored by damage for the particular gun type
	 * being used.
	 */
	public int getDamage()
	{
		return damage;
	}
	
	/**
	 * A simple method that returns the current GunType being stored by type.
	 */
	public GunType getGunType()
	{
		return type;
	}
	
	/**
	 * A method that first checks if the player's gun has any ammo, and, if so, runs the calculations to
	 * see if they hit with the shot being fired, returning a boolean respective to the result.
	 */
	public boolean attack()
	{
		if(currentAmmo == 0)
		{
			return false;
		}
		else
		{
			reduceAmmo();
			int hitChance = random.nextInt(100);
			if(hitChance < accuracy)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
	
	/**
	 * An alternative version of the attack method that is only accessible by enemies, allowing them to fire
	 * without fear of running out of ammo.
	 */
	public boolean attack2()
	{
		int hitChance = random.nextInt(100);
		if(hitChance < accuracy)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
