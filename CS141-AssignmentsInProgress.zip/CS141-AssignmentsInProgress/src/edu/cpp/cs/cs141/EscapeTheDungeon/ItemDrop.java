package edu.cpp.cs.cs141.EscapeTheDungeon;

/**
 * This class serves to define the two types of Item Drops that exist in the game,
 * which is checked and used later on in the GameEngine class.
 * @author Moyenne
 */
public class ItemDrop
{
	/**
	 * DropType is an enumerated type variable, which can be either HEALTH or AMMO
	 * values.
	 */
	public static enum DropType{HEALTH, AMMO};
	
	/**
	 * type is a variable of type DropType, allowing it to store the two different
	 * values listed above.
	 */
	private DropType type;
	
	/**
	 * A basic, default constructor that sets type to a default value of AMMO.
	 */
	public ItemDrop()
	{
		type = DropType.AMMO;
	}
	
	/**
	 *Another version of the constructor which accepts a parameter of type DropType,
	 *which is then assigned to type.
	 */
	public ItemDrop(DropType itemType)
	{
		type = itemType;
	}
	
	/**
	 * A simple method that returns the current DropType being stored by the type variable.
	 */
	public DropType getType()
	{
		return type;
	}
}
