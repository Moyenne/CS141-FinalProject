package edu.cpp.cs.cs141.EscapeTheDungeon;

import java.util.Scanner;

/**
 * This class serves to visualize game functions and accept choices from the player to interact
 * and progress with the game. Most of this class centers around the gameLoop, which allows the
 * game to repeat integral functions over and over until the game ends.
 * @author Moyenne
 */
public class UserInterface
{
	/**
	 * game is an initialized GameEngine object, which allows for all game rules and functions to
	 * be determined and accessed.
	 */
	private GameEngine game;
	
	/**
	 * scanner is an initialized Scanner object, which allows for the UserInterface to directly read
	 * user inputs via the keyboard, allowing for use of these inputs in various methods in the
	 * UserInterface class, as well as the GameEngine class.
	 */
	private Scanner keyboard;
	
	/**
	 * A constructor for the class that accepts a parameter of type GameEngine, setting game equal to
	 * the input value, as well as initializing the Scanner object that will be used to obtain future
	 * input values.
	 */
	public UserInterface(GameEngine game)
	{
		this.game = game;
		keyboard = new Scanner(System.in);
	}
	
	/**
	 * A method that begins the game, presenting the player with their first choice on the main menu
	 * as to whether or not they will continue the game. If they do continue, gameSetUp is called, and
	 * the player moves on to the next stage of game functions.
	 */
	public void startGame()
	{
		printStartMessage();
		boolean quit = false;
		while(!quit)
		{
			int option = mainMenu();
			
			switch(option)
			{
				case 1:
					gameSetUp();
					break;
				case 2:
					quit = true;
					break;
				default:
					System.out.println("Invalid option. Try again...");
					break;
			}
		}
	}
	
	/**
	 * A simple method that prints out a String message as an introduction to the player.
	 */
	private void printStartMessage()
	{
		System.out.println("Welcome to Escape the Dungeon v1.0!\n\n");
	}
	
	/**
	 * A method that prints out the contents of the main menu, then accepts the player's input to determine
	 * what step to take next.
	 */
	private int mainMenu()
	{
		int option = 2;
		System.out.println("Select an option:\n" + "\t1. Start New Game.\n" + "\t2. Quit.");
		option = keyboard.nextInt();
		keyboard.nextLine();
		return option;
	}
	
	/**
	 * A method that prints out the contents of the game set-up phase, then accepts the player's input as
	 * to what type of gun they would like to use. Once they have chosen, gameLoop is called, and the game's
	 * main functions begin.
	 */
	private void gameSetUp()
	{
		game.reset();
		System.out.println("New game started!");
		while(!game.getSetUp())
		{
			System.out.println("Choose your weapon now.\n" + "PISTOL\t" + "RIFLE\t" + "SHOTGUN");
			if(game.setUp(keyboard.nextLine()))
			{
				System.out.println("Choice successful, it's time to play!");
				gameLoop();
			}
			else
			{
				System.out.println("Invalid choice, please try again.");
			}
		}
	}
	
	/**
	 * A method that controls the main, repeating functions of the game, rerunning so long as the game is not
	 * in some way complete, accepting player choices for movement and action during different game phases. The
	 * game scolds the player for unacceptable inputs, congratulates the player when they are victorious, and mocks
	 * the player (not really) when they are defeated. When the game ends, the player is brought back to the main
	 * menu to begin the process anew.
	 */
	private void gameLoop()
	{
		System.out.println("The game has begun! " + "10 steps remaining to escape!\n");
		while(!game.gameOver())
		{	
			{
				if(game.inCombat())
				{
					if(game.isPlayerTurn())
					{
						System.out.println("Make your choice: Fight or Run!");
						System.out.println(game.displayStats());
						System.out.println(game.displayEnemyStats());
					}
					else
					{
						System.out.println("It's the enemy's turn! Press enter to test your luck!");
					}
				}
				else
				{
					System.out.println("You have but one choice... Take one step to continue.");
					System.out.println(game.displayStats());
				}
				if(!game.inCombat())
				{
					while(!game.takeMovementTurn(keyboard.nextLine()))
					{
						System.out.println("Really? You have one thing to type. Come on now.");
					}
				}
				else
				{
					while(!game.takeCombatTurn(keyboard.nextLine()))
					{
						System.out.println("Invalid move! Choose again...");
					}
				}
			}
			keyboard.nextLine();
		}
		if (game.victorious())
		{
			System.out.println("You win!\n");
		}
		else
		{
			System.out.println("Defeat! You lose.\n");
		}
		System.out.println("Press ENTER to continue...");
		keyboard.nextLine();
		System.out.println("\n\n\n"); 
		startGame();
	}
}
