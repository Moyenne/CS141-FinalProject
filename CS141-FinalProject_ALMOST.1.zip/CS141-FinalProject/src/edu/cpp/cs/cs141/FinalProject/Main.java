package edu.cpp.cs.cs141.FinalProject;

import java.util.Random;

/**
 * This class is what starts the whole ball rolling. Without this, you can't make
 * this program run, and that is a tragedy.
 * @author Team 404
 */
public class Main
{
	/**
	 * The main initializer for the entire program. Need I say more?
	 */
	public static void main(String[] args)
	{
		UI ui = new UI();
		ui.startGame();
	}
}