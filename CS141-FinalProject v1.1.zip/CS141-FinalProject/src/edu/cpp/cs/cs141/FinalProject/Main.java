package edu.cpp.cs.cs141.FinalProject;

import java.util.Random;

public class Main
{
	public static void main(String[] args)
	{
		//UI ui = new UI(new Engine());
		//ui.startGame();
	}
}
