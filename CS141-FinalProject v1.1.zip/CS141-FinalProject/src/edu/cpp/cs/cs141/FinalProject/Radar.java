package edu.cpp.cs.cs141.FinalProject;

public class Radar extends Item
{
	public Radar(int xPos, int yPos)
	{
		super(xPos, yPos, "Radar");
	}
}
