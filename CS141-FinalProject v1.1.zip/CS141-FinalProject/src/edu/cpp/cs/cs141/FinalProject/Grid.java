package edu.cpp.cs.cs141.FinalProject;

import java.util.Random;

public class Grid
{
	private GridObject[][] grid = new GridObject[9][9];
	
	public Grid()
	{
		generalGridSetup();
	}
	
	private void generalGridSetup()
	{
		Player player = new Player(0, 8);
		addGridObject(player, 0, 8);
		roomSetup();
		enemySetup();
		itemSetup();
	}

	private void roomSetup()
	{
		Room[] temp = new Room[9];
		Room room1 = new Room(1, 1, 1); temp[0] = room1;
		Room room2 = new Room(2, 4, 1); temp[1] = room2;
		Room room3 = new Room(3, 7, 1); temp[2] = room3;
		Room room4 = new Room(4, 1, 4); temp[3] = room4;
		Room room5 = new Room(5, 4, 4); temp[4] = room5;
		Room room6 = new Room(6, 7, 4); temp[5] = room6;
		Room room7 = new Room(7, 1, 7); temp[6] = room7;
		Room room8 = new Room(8, 4, 7); temp[7] = room8;
		Room room9 = new Room(9, 7, 7); temp[8] = room9;
		int x = new Random().nextInt(9);
		temp[x].placeBriefcase();
		addGridObject(temp[0], 1, 1);
		addGridObject(temp[1], 4, 1);
		addGridObject(temp[2], 7, 1);
		addGridObject(temp[3], 1, 4);
		addGridObject(temp[4], 4, 4);
		addGridObject(temp[5], 7, 4);
		addGridObject(temp[6], 1, 7);
		addGridObject(temp[7], 4, 7);
		addGridObject(temp[8], 7, 7);
	}
	
	private void enemySetup()
	{
		
	}

	private void itemSetup()
	{
		
	}
	
	public void addGridObject(GridObject gridObject, int xPos, int yPos)
	{
		grid[xPos][yPos] = gridObject;
	}
	
	public void removeGridObject(int xPos, int yPos)
	{
		grid[xPos][yPos] = null;
	}
	
	public GridObject getGridObject(int xPos, int yPos)
	{
		return grid[xPos][yPos];
	}
	
	public void moveGridObject(int currentXPos, int currentYPos, int newXPos, int newYPos)
	{
		//if(grid[newXPos][newYPos] == null)
		//{
			grid[newXPos][newYPos] = grid[currentXPos][currentYPos];
			grid[currentXPos][currentYPos] = null;
		//}
	}
}
