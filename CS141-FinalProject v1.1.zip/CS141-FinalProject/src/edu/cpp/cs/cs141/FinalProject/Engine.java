package edu.cpp.cs.cs141.FinalProject;

public class Engine
{
	private Grid grid = new Grid();
	private boolean isPlayerTurn = true;
	
	public void gameSetup()
	{
		
	}
	
	public boolean move()
	{
		return moveUp();
	}
	
	public boolean moveUp()
	{
		return true;
	}
	
	public boolean moveDown()
	{
		return true;
	}
	
	public boolean moveLeft()
	{
		return true;
	}
	
	public boolean moveRight()
	{
		return true;
	}
	
	public boolean shoot()
	{
		return shootUp();
	}
	
	public boolean shootUp()
	{
		return true;
	}
	
	public boolean shootDown()
	{
		return true;
	}
	
	public boolean shootLeft()
	{
		return true;
	}
	
	public boolean shootRight()
	{
		if(0 == 0 && 4 >= 2)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
