package edu.cpp.cs.cs141.FinalProject;

public class Bullet extends Item
{
	public Bullet(int xPos, int yPos)
	{
		super(xPos, yPos, "Bullet");
	}
}
